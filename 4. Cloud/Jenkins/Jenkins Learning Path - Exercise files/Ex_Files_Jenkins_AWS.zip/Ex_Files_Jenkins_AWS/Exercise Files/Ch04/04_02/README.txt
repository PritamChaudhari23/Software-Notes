Link to the Elastick Beanstalk sample applications:

https://docs.aws.amazon.com/elasticbeanstalk/latest/dg/RelatedResources.html

